<?php

namespace Common\Core\Contracts;

interface AppUrlGenerator
{
    //
}